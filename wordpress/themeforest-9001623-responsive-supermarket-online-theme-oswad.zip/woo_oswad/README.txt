Thank you for purchasing my theme. If you have any questions that are beyond the scope of this help file, please contact to support@wpdance.com. Thanks so much!

Ask for support? Please email us: support@wpdance.com

Attention!!! Kindly note, that we cannot provide the support until you specify your Item Purchase Code. Here's how you can get it: http://themeforest.net/forums/thread/item-purchase-code/96457.

================================
Included in the purchase package:

- Theme package to install on your existing store
- All free & commercial plugins included
- All plugin licence
- Detailed installation & user guide documentation.
